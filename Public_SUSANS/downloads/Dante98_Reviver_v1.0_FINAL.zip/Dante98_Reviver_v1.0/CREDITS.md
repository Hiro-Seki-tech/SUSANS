# CREDITS / サードパーティ ライセンス表記


## Dante98 Reviver — PLIP additions

Dante98 Reviver is a **PLIP project**.

PLIPがDante98 Reviverとして独自に追加したUI、ゲームZIP直接読込、Dante98 / Dante98II起動判定補助、
ZIP保存、タイトル導線、ヘルプ等の追加コードは **MIT License** で公開します。

Copyright (c) 2026 PLIP

これは第三者コンポーネントのライセンスを変更するものではありません。
QuuBee、NP2kai、fmgen、フォント、SoundFontその他の同梱物には、それぞれ本ファイルおよび
`LICENSE` / `LICENSE-MIT` / `licenses/` に記載された元のライセンスが適用されます。

---

## Acknowledgements / 謝辞

Dante98 ReviverとSUSANSのブラウザ復刻は、**QuuBee**、その基盤となる **NP2kai**、
そして多数の先人によるPC-98エミュレーション・音源・フォント等の技術の上に成り立っています。
これらを開発・公開し、未来へつないできたすべての開発者・貢献者に深く感謝します。

### Special Thanks

**赤森貴太郎** — QuuBeeを紹介し、SUSANSのブラウザ復刻とDante98 Reviver誕生への
重要なきっかけを与えてくれた友人。彼の紹介が、この復刻を大きく前へ進めました。

---


QuuBee が同梱・配布する第三者アセットおよびコンポーネントの著作権表示。
（QuuBee 自身が再配布・ホスティングするのは下記。ゲーム/ソフト本体はユーザーが用意するフリーソフトであり、
QuuBee は配布しない。）

---

## プロジェクト全体のライセンス

- **配布物（`np2kai_core.wasm` を含むアプリ全体）: 寛容ライセンスの集合体（GPL なし）**。
  内訳は下表のとおり BSD-3 / 2 条項 BSD / MIT / fmgen 独自（フリーソフト配布）で、いずれも
  「著作権表示を添えれば再配布可」の寛容ライセンス。**コピーレフト（GPL）部品はビルドに含めていない**
  （FPU は GPL の DOSBox 由来ではなく BSD の Berkeley SoftFloat 3e を使用。経緯は下記 ＊）。
- **QuuBee 独自のソース（msonrm 著作の部分）: `MIT`**（`LICENSE-MIT`）。
- 「著作権クリーン」＝ NEC BIOS / MS-DOS 等 proprietary を**同梱しない**こと。加えて、配布バイナリ内の
  各部品ライセンスも相互に整合している（下記 ＊ のとおり 2026-06-26 に GPL 部品を除去して整合化）。

| コンポーネント | ライセンス |
|---|---|
| QuuBee 独自コード（`native/` の `qb_*`/`bridge`/`dos_*`、`web/player/`、`tools/`、`docs/` 等） | MIT |
| NP2kai ラッパ本体（AZO234） | MIT |
| i386c CPU コア（NONAKA Kimihiro 他） | BSD（2 条項） |
| **FPU `softfloat3`（Berkeley SoftFloat 3e, Regents of the University of California）** | **BSD-3-Clause** |
| FM 音源 `fmgen`（cisc） | fmgen 独自（フリーソフト配布・下記 ＊＊） |
| 音源チップ `mamebsd`（MAME の BSD 部分） | BSD-3-Clause |
| `web/assets/font.bmp` | 修正 BSD |
| `native/third_party/tsf.h`（TinySoundFont, Bernhard Schelling） | MIT |
| `web/assets/soundfont.sf2`（GeneralUser GS, S. Christian Collins） | 寛容ライセンス（下記） |
| `tools/testdata/boot.d88`（FreeDOS(98)・テスト専用素材／**デプロイ非同梱**） | GPL |
| `tools/testdata/VZ.COM`（VZ Editor・テスト専用素材／**デプロイ非同梱**） | BSD-3-Clause |

> ＊ **ライセンス整合化（2026-06-26）**: FPU を NP2kai 同梱の BSD 実装 **Berkeley SoftFloat 3e**
> （`SUPPORT_FPU_SOFTFLOAT3`、本家 NP21/W も rev.98 以降この構成）に切替え、配布バイナリから GPL 部品を
> 除去した（DOSBox 由来 FPU のソースはサブモジュールに残るがビルド対象外）。経緯は CHANGELOG.md /
> `msonrm/quubee` Issue #1 を参照。
>
> ＊＊ **fmgen の条件**: cisc 氏のライセンスは「著作権表示・免責の保持」「改変箇所の明示」に加え、**配布は
> フリーソフトに限る／商用ソフトへの組込みは事前許諾が必要**という条件を持つ（このため GPL とは非互換）。
> QuuBee は無償のフリーソフトとして配布するためこの条件を満たす。全文は `core/np2kai/sound/fmgen/fmgen_readme.txt`。

---

## フォント — `web/assets/font.bmp`

Neko Project II 系エミュレータ用の **代替フォントビットマップ**。ベースは「さざなみフォント」で、
東雲 (Shinonome) / 美咲 (Misaki) / M+ FONTS / Ayu / Oradano / Kappa 等の自由フォント、および
Neko Project II 内蔵グリフを組み合わせたもの。配布元の表記に従い、**全体として修正 BSD ライセンス**。

**QuuBee が同梱する `font.bmp` は、この SimK 版を素材に 2 段階で再生成したもの**（再生成パイプラインと
素材一式は `tools/font_build/` に収録、ビルド時のみ・配布対象外）:

1. **縦位置の正規化**: SimK 版は漢字に最大 1px のランダムな縦ズレがある。これを **東雲フォント
   (Shinonome `shnmk16.bdf`, Public Domain) で全二バイトグリフを上書きして揃える**。手法・スクリプト
   (`makefont.cjs`) は **irori 氏の np2-wasm `adjust-fontbmp`**（BSD-3-Clause, Copyright NP2 developer team）
   由来。NEC 機種依存文字（区9-13）と単バイト ANK は上書きせず SimK 版を保持する。
2. **JIS 区8 罫線素片の付加**: 区8（全角罫線）は **JIS X 0208-1983 での追加で、JIS78 ベースの NEC PC-98
   実機 ROM には無い**（実機の箱描画は区9-11 の NEC 半角グラフィック側）。SimK 版・irori 版とも区8 は空。
   QuuBee は JIS83 区8 を前提に書く一部ソフト（VZ Editor の GAME 等）を動かすため、区8 点1-32 を
   **幾何形状から自前生成して付加する**（`tools/gen_keisen_glyphs.py`、実機再現ではなく意図的な拡張）。

各素材のライセンス: 東雲フォント = **Public Domain**（古川泰之氏設計・/efont/ 改変、`licenses/fonts/`
収録済み）、`makefont.cjs` 等 = **BSD-3-Clause**（np2-wasm）、ビルド時に使う BDF パーサ `erkkah/BDF.js` =
**MPL 2.0**（配布物には含まれない）。区8 罫線は QuuBee 自作。

```
Copyright (c) 2025, SimK, Nekosan development team
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
3. Neither the name of the copyright holder nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
```

構成フォントの個別ライセンス（東雲 / 美咲 / M+ / Ayu / Oradano / Kappa / さざなみ、および
`font.bmp` 本体の Nekosan/SimK 宣言）は **`licenses/fonts/` に全文を収録**している（出典は配布
アーカイブ `sazanami-fontbmp.zip` の `doc/<フォント名>/`、原本の文字コードのまま温存）。いずれも
自由に再配布可能なライセンス。デプロイ（`tools/deploy.sh`）はこの `licenses/` と本 `CREDITS.md` を
公開ビルド `dist/` に同梱するので、**配布物自体が帰属表示を伴う**（修正 BSD のバイナリ再配布条項を満たす）。

---

## エミュレータコア — NP2kai (`core/np2kai`, git submodule)

AZO234 / Neko Project II kai。ラッパ本体の `LICENSE` は **MIT**（Copyright (c) 2017 AZO）。
QuuBee がビルドする WebAssembly には NP2kai が静的リンクされる。NP2kai は複数ライセンスの集合体で、
QuuBee のビルドに含まれる主なものは:

- **i386c CPU コア**（`i386c/`, Copyright NONAKA Kimihiro 他）— **2 条項 BSD**（permissive）。
- **FPU エミュレータ**: **Berkeley SoftFloat 3e**（`i386c/ia32/instructions/fpu/softfloat3/`,
  Copyright The Regents of the University of California）＋ ラッパ `fpemul_softfloat3.cpp`
  （Copyright NONAKA Kimihiro）— **いずれも BSD-3-Clause**。QuuBee は `SUPPORT_FPU_SOFTFLOAT3` で
  これをコンパイルする。**GPL の DOSBox 由来 FPU（`fpemul_dosbox*.c`）はビルドに含めない**
  （サブモジュールにソースは在るがコンパイル対象外）。経緯は上記 ＊。
- **FM 音源 `fmgen`**（`sound/fmgen/`, Copyright (C) cisc 1998, 2003）— cisc 氏独自ライセンス。
  配布はフリーソフトに限る／商用組込みは要許諾（GPL 非互換。上記 ＊＊）。QuuBee は無償配布のため適合。
- **音源チップ `mamebsd`**（MAME の BSD-3 部分）— BSD-3-Clause。GPL の `mame` 版は使用しない。
- opngen / VERMOUTH 等の他部品のライセンスは `core/np2kai` 配下の各ディレクトリを参照
  （VERMOUTH はビルド除外）。

各ファイルの著作権ヘッダは改変・削除せず温存している。

---

## MIDI 合成エンジン — `native/third_party/tsf.h` (TinySoundFont)

ブラウザでの MIDI 演奏に **TinySoundFont**（単一ヘッダの SF2 ソフトシンセ）を使用。
**MIT ライセンス**、Copyright (C) 2017–2025 Bernhard Schelling（SFZero, Copyright (C) 2012 Steve Folta
に基づく）。`native/qb_tsf.c` がこれを用いて SF2 をネイティブ再生する（旧 VERMOUTH/GUS .pat 経路を置換）。
ヘッダの著作権表示は温存している。

## MIDI 音色 — `web/assets/soundfont.sf2` (GeneralUser GS)

MIDI の音色バンクに **GeneralUser GS v2**（GM/GS 互換 SoundFont、作者 S. Christian Collins）を使用。
ライセンスは寛容で、原文（`documentation/LICENSE.txt`）いわく「自分の音楽制作・私的/商用を問わず制限なく
使用してよい。ソフトウェアプロジェクトでの使用も自由で、バンクやパッケージの改変も可」。再配布・同梱が
明示的に許可されている（QuuBee はローカルコピーを同梱・配布する。作者は直リンクでなくローカルコピー配布を推奨）。
作者の正直な注記として「一部サンプルの出自は完全には確証できない（ただし自由に入手可能なもので、商用音源 CD
由来のものは含まれない）」とある。proprietary ROM を同梱しないという QuuBee のクリーン方針とは別軸の留保だが、
ライセンス上は再配布が許諾されている。配布元: https://www.schristiancollins.com 。
SF2 本体は ~32MB と大きいためリポジトリには含めず（`.gitignore`）、`tools/setup_soundfont.sh` で取得する。
ただし**ライセンス全文（License v2.0）は `licenses/soundfont-GeneralUser-GS-LICENSE.txt` に収録**し、
デプロイにも同梱する（SF2 本体と一緒に公開ビルドへ届く）。
別の SF2 に差し替えるのも自由（TSF が読める SF2 を `web/assets/soundfont.sf2` に置くだけ・コード変更不要）。

---

## FreeDOS — `tools/testdata/boot.d88`

FreeDOS(98) の 2HD フロッピーイメージ（**GPL**、再配布可）。headless テスト
（`tools/bench_frame.js` / `tools/diskimage_test.js`）専用の素材で、**デプロイ対象外**
（サイトには含まれない。帰属: The FreeDOS Project）。

---

## VZ Editor — `tools/testdata/VZ.COM`

PC-98 版 VZ Editor Ver1.60 の実行ファイル（**BSD-3-Clause**、再配布は著作権表示の保持が条件）。
HLE-DOS の起動回帰（`tools/vz_test.js`、VZ の `checkhard` が要求する INT DCh≠DDh ベクタの検証）
専用の素材で、**デプロイ対象外**（サイトには含まれない）。原作 兵藤嘉彦（c.mos）氏、ソース公開
vcraftjp <https://github.com/vcraftjp/VZEditor>。ライセンス全文は `tools/testdata/VZ.LICENSE.txt`。

---

## PMD (Professional Music Driver) — PC-98 FM 音楽 .M の再生

PC-98 同人 FM 音楽の事実上の標準フォーマット `.M`(PMD)を QuuBee 内で再生するため、KAJA(梶原正裕)氏作の
**PMD ドライバ + PMP プレイヤ**を同梱する。KAJA 氏は 2019/12/25 に PMD/MC/PMP の全ソースを公開し、
「ソースについての著作権は放棄しませんが、**ご自由に使って頂いて構いません**。むしろ…再利用するアイデアが
あるようでしたら、ぜひ利用してやってください」と明記している。QuuBee はこの自由公開ソースから**自分自身で
バイナリをビルド**する(1997 配布バイナリは「無断の改変・営利使用を禁ず」の別ライセンスなので使わない)。

ビルドは `tools/pmd_build/build_pmd.sh`(MASM 互換アセンブラ UASM を用意し、OPTASM→UASM の機械的な
移植補正を当てて `PMD86.COM` + `PMP.COM` を生成)。素性が完全にクリーンなバイナリのみを同梱する。
**再現性のためソースは commit に pin** し、同梱バイナリの SHA-256 を記録してある（`tools/pmd_build/README.md`
の「再現性」節）。pin ソースからの再ビルドが同梱バイナリと **byte 完全一致**することは確認済（2026-06-26）で、
誰でも同スクリプトで再ビルドして同じハッシュを得られる。
帰属: PMD / MC / PMP © M.Kajihara (KAJA)。原典ソース: https://github.com/d2lmirrors/pmd (KAJA 2019 公開のミラー)。
C60 氏の PMDWin は使用していない(連絡許諾が要るため。Path B は KAJA のドライバのみで完結)。

---

## OPNA リズム音源の代替音色 — `web/assets/rhythm/2608_*.wav`

YM2608(OPNA)の内蔵リズム音源(バスドラ/スネア/シンバル/ハイハット/タム/リム)を鳴らすには、チップ内蔵 ROM
相当のサンプルデータが要る。本物の YM2608 リズム ROM はヤマハの著作物なので同梱できない(NEC BIOS を同梱しない
のと同じ理由)。そこで font.bmp が NEC フォント ROM の代替であるのと同様に、**クリーンな代替音色**を使う:

メモル氏(J'aime la musique, http://sound.jp/jaime/)が**独自に作成**した「YM2608風リズム音源音色データ」
**2608modoki2**(Ver.2.0)。作者本人が「手持ちの音源から音色を集め、YM2608のリズム音に似せてエディットした」
独自素材であり、ヤマハ ROM のダンプではない。配布同梱の利用条件で「**配布・転載・ソフトへの組み込み等、有償
無償にかかわらずご自由にどうぞ**」と明示されている(原文は `web/assets/rhythm/PROVENANCE_2608modoki2.txt`)。
作者は「組み込んだ場合は何のタイトルに使ったか知らせてくれると嬉しい」としており、これは QuuBee の③敬意の柱に
沿うので連絡したい(KAJA への姿勢と同じ)。本物の OPNA とは波形が根本的に異なるため音色は完全一致ではない。

帰属: 2608modoki2 © メモル (J'aime la musique)。入手元: http://sound.jp/jaime/ 。

---

## PC-98 画像フォーマット — Pi (`.PI`) / MAG (`.MAG`) のデコード

PC-98 のフリーソフト/同人 CG 文化で標準的に使われた 2 大画像フォーマット **Pi** と **MAG (MAKI02)** を
ビューアで表示するため、QuuBee は**フォーマットの事実だけを用いた自前デコーダ**を持つ
(`web/player/piimage.js` / `web/player/magimage.js`、QuuBee 独自コードなので **MIT**)。
画像ファイルそのものも第三者のローダ/ライブラリのバイナリ・ソースも**一切同梱しない**。

**Pi 形式**は柳沢明氏が考案 (X68 版 Pi.r が原典)、PC-98 用ローダ/セーバは電脳科学研究所/BERO (石尾孝弘氏)
による。組み込み用ローダ (`pi24.lzh` の `piloadc.asm` 等) のドキュメントには「資料が完全に公開されている」
「転載・使用は私の承認無しに自由」「組み込みに当たりソースの変更などなさってもかまわない」「営利目的で使用しても
構わない」と明記され、**唯一の条件が「その事をどこかに一言書いて下さい (簡単には見れない所でも可)」**である。
本項がその一言にあたる。QuuBee はこの公開資料を仕様リファレンスに参照したが、コードは逐語移植せず独自に実装した
(検証は同一画像の Pi 版と MAG 版がピクセル単位で一致することによる、`tools/pi_test.js`)。

帰属: Pi format © 柳沢明 / PC-98 ローダ © 電脳科学研究所・BERO (石尾孝弘)。MAG (MAKI02) format © woody-RINN ほか。

---

## キー配列エンジン — `web/assets/keymap-engine.js` + `web/assets/keymaps/*.json`

新配列 (薙刀式 / NICOLA / 親指ぴゅん 1キー版 / 月配列 2-263 / AZIK / Colemak ローマ字 / 標準ローマ字の
7 本) の物理キー入力 → かな解決を担う **KeymapEngine**。HLE FEP のかな入力前段として組み込む
(かな漢字変換は従来どおりホスト側 Mozc-Wasm が担当)。

- **出所**: `msonrm/logical-layout-labo` (Copyright © 2026 Narumi Masao、**MIT**)。同 web ワークスペースの
  `web/src/engine` を rolldown で 1 ファイルに UMD バンドルした単体成果物 (`npm run build:engine` の出力
  `web/public/engine/keymap-engine.js`)。**QuuBee は fork せず成果物 1 ファイルを vendoring** する
  (mozc.data と同じ「差し替えで取り込む」方針)。エンジンの正しさの正典は labo の golden テスト。
- **取り込みバージョン**: `KeymapEngine.version` = **2.0.0** / keymap-format **2.0** (labo main
  **89d8cbc**)。1.1.0 で `onHostAction` 追加、1.2.0 で convert/confirm/insertAndConfirm も転送、
  1.3.0 で同時押し判定モード `judgment: "mutual"` = 相互シフト (時間不使用)、1.4.0 で英数モードの
  chord 解釈 + mutual 再入 reset 修正、1.6.0 で逐次系 (AZIK/月/Colemak/JSON ローマ字) の Space を
  変換にする + `, .` → `、。` + BS 後の pending 復帰、1.8.0 で役に載ったスペースの単打が死ぬ問題を修正、
  1.9.0/1.10.0 でアクション文字列パーサを 1 本化 (面ごとに語彙を強制) + 読み込み診断 `onDiagnostic`、
  **2.0.0 で keymap-format v2** — **JIS/US は配列でなくレイアウトの選択**になった。
  - 配列が決めるのは**役** (`holder1` = 左親指 等) までで、それをどの物理キーに置くかは環境の関心事
    なので、ホストが `decodeKeymap(json, { layout })` で `"jis"` / `"us"` を渡す。QuuBee は設定
    パネルの Keyboard (US/JIS) をそのまま渡す (`bridge.js` の `setFepLayout`)。
  - **配列ファイルが 14 本 → 7 本** (`naginata_jis.json` + `naginata_us.json` → `naginata.json` 等)。
    新規に `oyayubi_pyun_1key.json` (親指ぴゅん 1キー版) が加わった。**名前から JIS/US が消えた**
    (`ローマ字(QWERTY JIS)` → `ローマ字（QWERTY）`)。
  - **版ゲートは相互に非互換**: v1 の JSON を v2 エンジンに渡すとエラー、v2 の JSON を v1 エンジンに
    渡してもエラー。**engine / hechima / keymaps の 3 点は必ずセットで差し替えること**
    (回帰 `tools/keymap_engine_test.js` が v1 JSON の拒否も含めて縛る)。
  - NICOLA は配列そのものも 1 か所変わった: `;` の左親指シフト (交差シフト) に置いていた `ー` を削除
    (日本語入力コンソーシアムの規格書はこのセルの交差シフト面に文字を割り当てておらず、`X` キーとも
    重複していた)。左親指 + `;` は定義が無くなり単打の「ん」に落ちる。**薙刀式 v18** (space+W/R の
    め⇔ね 入れ替え。作者 大岡俊彦氏 発表) は据え置き。
  更新時は labo で `npm run build:engine` → `web/public/engine/keymap-engine.js` と `web/public/keymaps/*.json`
  を本ディレクトリへコピーし、本項の version/commit を更新する。受け入れ検査 = `tools/keymap_engine_test.js`。
- 依存: React/DOM/Next 非依存の純ロジック (ブラウザ `<script>` / Worker `importScripts` / node `require` 対応)。
- 帰属: keymap-format / InputEngine © 2026 Narumi Masao (MIT)。QuuBee は改変せず同梱のみ。

---

## HLE FEP の変換スタック — `web/assets/hechima.js` + `web/assets/hechima-wasm.{js,wasm}` + `web/assets/mozc.data`

日本語入力 (HLE FEP) の変換セッション層とかな漢字変換エンジン。ビルド・正典はどちらも
`msonrm/logical-layout-labo` にあり、**QuuBee は同リポの GitHub Release から成果物を pin して
vendoring** する (keymap-engine と同じ差し替えモデル)。QuuBee 固有物は bridge.js の cb 実装のみ。

- **hechima.js** (変換セッション層): Copyright © 2026 Narumi Masao、**MIT**。UMD 単体成果物
  (グローバル `Hechima`)。取り込み = **`Hechima.version` 0.19.0** (labo main **89d8cbc** の
  `web/public/hechima/hechima.js`。0.2.0 で文節伸縮 `cb.resize` +
  editSegmentLeft/Right、0.3.0 で Phase 2 の chord routing 修正 + Shift+←→ 伸縮、0.8.1 で Phase 2 の
  BS/Escape = よみに戻す、0.12.0 で合成中 confirm = 無変換即確定 (薙刀式 V+M)、0.13.1 で内蔵ローマ字の
  BS 後 pending 復帰、0.14.0 で候補の二層化 API (`setFold` 等 — QuuBee は未使用 = 挙動不変)、
  0.16.0 で engine の `insertSpace` 受け入れ (空バッファ Space → 全角スペースを commit / Shift = 半角)、
  0.17.0 で Shift+英字の英字合成が engine 挿し時にも効く (英字は Mozc へ投げない)、0.18.0 で
  候補選択中の Shift+Space = 前候補が engine 挿し時にも効く、0.19.0 で engine へ `hostPhase` を
  渡し (idle/composing/selecting)、アクションの `when` 条件が状態を見て発火するようになった。
  **keymap-engine 2.0.0 とセット必須** — 版を跨いで混ぜると `hostPhase` の受け口が無い / 逐次系の
  Space が「よみのまま確定」に戻る)。
  なお labo が併配布する `hechima-worker.js` は**取り込まない**。QuuBee は自前の
  `web/player/mozc-worker.js` で hechima-wasm を駆動しており (hechima.js には cb 実装を渡す形)、
  labo の worker は OPFS 学習永続化と `hechima_sync` を前提とするため pin 中の hechima-wasm v0.2.0
  では動かない。
- **hechima-wasm.{js,wasm} + mozc.data** (かな漢字変換エンジン): fcitx-contrib/fcitx5-mozc 由来の
  Emscripten ビルド、**BSD-3・powered by Mozc** (mozc 本体 = Google、BSD-3)。取り込み = Release
  **hechima-wasm-v0.2.0** (labo **29b6271** / fcitx5-mozc **8b3d34c** / mozc **0651fbc** / emsdk 3.1.69。
  0.2.0 で `hechima_resize` = Mozc ResizeSegment 追加)。辞書 mozc.data (~19MB) は FEP 初回 ON で
  遅延 fetch。配信は事前圧縮版 `mozc.data.gz` (~12.6MiB、同一成果物を gzip したもの = ライセンスも同一)
  を優先し、無い環境では素の mozc.data へ自動フォールバックする (deploy.sh が dist に無ければ生成)。
  **辞書を差し替えるときは `web/assets/mozc.data.gz` を先に消す** — 手元に古い .gz が残っていると
  worker がそちらを優先し、新しい辞書が使われない (deploy.sh は「無ければ作る」だけで作り直さない)。
- 更新時は Release 添付の BUILD_INFO.txt と本項・`web/player/mozc-worker.js` 冒頭の pin 記載を揃える。
  受け入れ検査 = `tools/fep_mozc_test.js` / `tools/fep_resize_test.js` / `tools/fep_space_test.js`。

---

## QuuBee 自身

QuuBee のブリッジ層・フロントエンド・ツール群（`native/` の `qb_*`/`bridge`/`dos_*`、`web/player/`、
`web/index.html`、`tools/`、`emscripten/`、`docs/` 等、msonrm 著作の部分）は **MIT**（`LICENSE-MIT`）。
配布バイナリ全体は GPL 部品を含まない寛容ライセンスの集合体で（上記＊で整合化済み・全体像は冒頭の表）、
QuuBee 独自部分は MIT 単独で再利用できる（fmgen の「フリーソフト配布」条件のみバイナリ全体に及ぶ）。
BIOS は NEC の ROM を使用せず NP2kai の合成 BIOS を用い、DOS は MS-DOS を使用せず INT 21h を独自に
HLE 実装している（proprietary 非同梱という意味で「著作権クリーン」）。
